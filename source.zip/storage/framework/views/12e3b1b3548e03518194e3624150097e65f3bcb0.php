<?php $__env->startPush('head'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/crudbooster/assets/summernote/summernote.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('bottom'); ?>
    <script type="text/javascript" src="<?php echo e(asset('vendor/crudbooster/assets/summernote/summernote.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>
