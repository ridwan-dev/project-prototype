<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FrontController extends Controller
{
    public function get_index(){
        $data['page_title']="test";
        return view('layout',$data);
    }
}
